# coding=utf-8
SPIDER_DEFAULT_HEADERS = {"User-Agnet":"Mozilla/5.0 (iPhone; CPU iPhone OS 9_1 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13B143 Safari/601.1"}
MONGO_HOST = "127.0.0.1"
MONGO_PORT = 27017
MONGO_DB = "douban"
MONGO_COLLECTION = "tv1"